import pandas as pd
from sklearn.ensemble import RandomForestRegressor
import joblib

df = pd.read_csv("server/data/wildfire_training.csv")
X = df[["temp", "humidity", "vegetation", "rainfall"]]
y = df["fire_risk"]
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X, y)
joblib.dump(model, "server/models/wildfire.pkl")
print("✅ Wildfire prediction model saved!")
