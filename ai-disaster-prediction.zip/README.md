# 🌍 AI Disaster Prediction System

Predict **Wildfires, Floods, and Landslides** up to **24 hours in advance** using real NASA and NOAA data.

## ⚙️ Installation
```bash
git clone https://github.com/<your-username>/ai-disaster-prediction.git
cd ai-disaster-prediction
pip install -r requirements.txt
```

## 🧠 Train Models
```bash
python train_wildfire_model.py
```

## 🚀 Run the API
```bash
uvicorn server.app:app --reload
```

Then open:
```
http://127.0.0.1:8000/api/ai/predict/fires?lat=12.97&lon=77.59
```
