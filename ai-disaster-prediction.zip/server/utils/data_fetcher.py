import requests
import pandas as pd
from datetime import datetime, timedelta

NASA_POWER_URL = "https://power.larc.nasa.gov/api/temporal/hourly/point"
NOAA_GFS_URL = "https://api.open-meteo.com/v1/gfs"

def fetch_nasa_data(lat, lon, hours_ahead=24):
    end_time = datetime.utcnow() + timedelta(hours=hours_ahead)
    params = {
        "parameters": "T2M,RH2M,PRECTOTCORR",
        "community": "RE",
        "longitude": lon,
        "latitude": lat,
        "format": "JSON",
        "start": datetime.utcnow().strftime("%Y%m%d"),
        "end": end_time.strftime("%Y%m%d"),
    }
    r = requests.get(NASA_POWER_URL, params=params)
    if r.status_code == 200:
        data = r.json()
        records = []
        for ts, values in data["properties"]["parameter"]["T2M"].items():
            records.append({
                "time": ts,
                "lat": lat,
                "lon": lon,
                "temp": values,
                "humidity": data["properties"]["parameter"]["RH2M"][ts],
                "rainfall": data["properties"]["parameter"]["PRECTOTCORR"][ts]
            })
        return pd.DataFrame(records)
    return pd.DataFrame()

def fetch_noaa_forecast(lat, lon, hours_ahead=24):
    params = {
        "latitude": lat,
        "longitude": lon,
        "hourly": ["precipitation", "soil_moisture_0_to_10cm"],
        "forecast_days": int(hours_ahead / 24),
        "timezone": "UTC"
    }
    r = requests.get(NOAA_GFS_URL, params=params)
    if r.status_code == 200:
        d = r.json()
        times = d["hourly"]["time"]
        df = pd.DataFrame({
            "time": times,
            "rainfall": d["hourly"]["precipitation"],
            "soil_moisture": d["hourly"]["soil_moisture_0_to_10cm"],
            "lat": lat, "lon": lon
        })
        return df
    return pd.DataFrame()
