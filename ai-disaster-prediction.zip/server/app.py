from fastapi import FastAPI
from fastapi.responses import JSONResponse
import joblib
from utils.data_fetcher import fetch_nasa_data, fetch_noaa_forecast

app = FastAPI(title="AI Disaster Prediction API", version="2.0")

fire_model = joblib.load("server/models/wildfire.pkl")
flood_model = joblib.load("server/models/flood.pkl")
landslide_model = joblib.load("server/models/landslide.pkl")

def df_to_geojson(df, risk_col, name):
    features = []
    for _, row in df.iterrows():
        features.append({
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [row.lon, row.lat]},
            "properties": {"risk": float(row[risk_col]), "type": name, "time": row.time}
        })
    return {"type": "FeatureCollection", "features": features}

def predict_fire(lat, lon):
    df = fetch_nasa_data(lat, lon, hours_ahead=24)
    if df.empty:
        return None
    df["vegetation"] = 0.6
    df["fire_risk"] = fire_model.predict(df[["temp", "humidity", "vegetation", "rainfall"]])
    return df_to_geojson(df, "fire_risk", "fire")

def predict_flood(lat, lon):
    df = fetch_noaa_forecast(lat, lon, hours_ahead=24)
    if df.empty:
        return None
    df["flood_risk"] = flood_model.predict(df[["rainfall", "soil_moisture"]])
    return df_to_geojson(df, "flood_risk", "flood")

def predict_landslide(lat, lon):
    df = fetch_noaa_forecast(lat, lon, hours_ahead=24)
    if df.empty:
        return None
    df["vegetation"] = 0.5
    df["landslide_risk"] = landslide_model.predict(df[["rainfall", "soil_moisture", "vegetation"]])
    return df_to_geojson(df, "landslide_risk", "landslide")

@app.get("/api/ai/predict/{disaster}")
def get_prediction(disaster: str, lat: float = 0.0, lon: float = 0.0):
    if disaster == "fires":
        geo = predict_fire(lat, lon)
    elif disaster == "floods":
        geo = predict_flood(lat, lon)
    elif disaster == "landslides":
        geo = predict_landslide(lat, lon)
    else:
        return JSONResponse(status_code=404, content={"error": "Invalid disaster type"})
    if geo is None:
        return JSONResponse(status_code=500, content={"error": "Failed to fetch data"})
    return JSONResponse(content=geo)
